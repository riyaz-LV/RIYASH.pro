# Aurora — setup

This folder has every source file the spec calls for, copied exactly:
`package.json`, `vite.config.ts`, `index.html`, `src/index.css`, `src/main.tsx`,
`src/App.tsx`, `src/components/Navbar.tsx`, `src/components/Hero.tsx`,
`public/favicon.svg`.

Two steps this sandbox has no network access to run, so do them locally:

```bash
npm install
curl -L https://pub-1e5b4001b36b47e28e6a2fb775966a79.r2.dev/templates/aurora/hero.mp4 -o public/hero.mp4
npm run dev
```

Everything else (Tailwind v4 wiring, the `@tailwindcss/vite` plugin,
Google Fonts links, framer-motion, all component code) is already in place —
these two commands are all that's left before `npm run dev` shows the page.
